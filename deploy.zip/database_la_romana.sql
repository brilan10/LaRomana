-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: la_romana
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administradores`
--

DROP TABLE IF EXISTS `administradores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administradores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administradores`
--

LOCK TABLES `administradores` WRITE;
/*!40000 ALTER TABLE `administradores` DISABLE KEYS */;
INSERT INTO `administradores` VALUES (1,'Dueño Administrador','admin@laromana.cl','$2y$10$bW1B8uG/W/FjNEpd3oqL9OgAofsmY1hehuzYBkHqkp3v2Racsy8FC','2026-09-01 15:40:54');
/*!40000 ALTER TABLE `administradores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Capilares'),(2,'Perfumes y Decants'),(3,'Gorras y Accesorios');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierres_diarios`
--

DROP TABLE IF EXISTS `cierres_diarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cierres_diarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `efectivo_inicial` decimal(10,2) DEFAULT 0.00,
  `porcentaje_barbero` decimal(5,2) NOT NULL DEFAULT 60.00,
  `porcentaje_tienda` decimal(5,2) NOT NULL DEFAULT 40.00,
  `total_ingresos` decimal(10,2) DEFAULT 0.00,
  `total_barberos` decimal(10,2) DEFAULT 0.00,
  `total_tienda` decimal(10,2) DEFAULT 0.00,
  `cerrado_por_admin` tinyint(1) DEFAULT 0,
  `fecha_cierre` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierres_diarios`
--

LOCK TABLES `cierres_diarios` WRITE;
/*!40000 ALTER TABLE `cierres_diarios` DISABLE KEYS */;
INSERT INTO `cierres_diarios` VALUES (1,'2026-08-17',0.00,60.00,40.00,54000.00,32400.00,21600.00,1,'2026-09-23 00:53:51'),(2,'2026-08-18',0.00,60.00,40.00,64000.00,38400.00,25600.00,1,'2026-09-23 00:53:51'),(3,'2026-08-19',0.00,60.00,40.00,52000.00,31200.00,20800.00,1,'2026-09-23 00:53:51'),(4,'2026-08-21',0.00,60.00,40.00,104000.00,62400.00,41600.00,1,'2026-09-23 00:53:51'),(5,'2026-08-22',0.00,60.00,40.00,96000.00,57600.00,38400.00,1,'2026-09-23 00:53:51'),(6,'2026-08-24',0.00,60.00,40.00,68000.00,40800.00,27200.00,1,'2026-09-23 00:53:51'),(7,'2026-08-25',0.00,60.00,40.00,84000.00,50400.00,33600.00,1,'2026-09-23 00:53:51'),(8,'2026-08-26',0.00,60.00,40.00,80000.00,48000.00,32000.00,1,'2026-09-23 00:53:51'),(9,'2026-08-27',0.00,60.00,40.00,34000.00,20400.00,13600.00,1,'2026-09-23 00:53:51'),(10,'2026-08-28',0.00,60.00,40.00,100000.00,60000.00,40000.00,1,'2026-09-23 00:53:51'),(11,'2026-08-29',0.00,60.00,40.00,116000.00,69600.00,46400.00,1,'2026-09-23 00:53:51'),(12,'2026-08-31',0.00,60.00,40.00,106000.00,63600.00,42400.00,1,'2026-09-23 00:53:51'),(13,'2026-09-01',0.00,60.00,40.00,92000.00,55200.00,36800.00,1,'2026-09-23 00:53:51'),(14,'2026-09-02',0.00,60.00,40.00,167000.00,100200.00,66800.00,1,'2026-09-23 00:53:51'),(15,'2026-09-03',0.00,60.00,40.00,63000.00,37800.00,25200.00,1,'2026-09-23 00:53:51'),(16,'2026-09-04',0.00,60.00,40.00,12000.00,7200.00,4800.00,1,'2026-09-23 00:53:51'),(17,'2026-09-05',0.00,60.00,40.00,205000.00,123000.00,82000.00,1,'2026-09-23 00:53:51'),(18,'2026-09-07',0.00,60.00,40.00,73000.00,43800.00,29200.00,1,'2026-09-23 00:53:51'),(19,'2026-09-08',0.00,60.00,40.00,86000.00,51600.00,34400.00,1,'2026-09-23 00:53:51'),(20,'2026-09-09',0.00,60.00,40.00,82000.00,49200.00,32800.00,1,'2026-09-23 00:53:51'),(21,'2026-09-10',0.00,60.00,40.00,88000.00,52800.00,35200.00,1,'2026-09-23 00:53:51'),(22,'2026-09-11',0.00,60.00,40.00,130000.00,78000.00,52000.00,1,'2026-09-23 00:53:51'),(23,'2026-09-12',0.00,60.00,40.00,121000.00,72600.00,48400.00,1,'2026-09-23 00:53:51'),(24,'2026-09-14',0.00,60.00,40.00,130000.00,78000.00,52000.00,1,'2026-09-23 00:53:51'),(25,'2026-09-15',0.00,60.00,40.00,172000.00,103200.00,68800.00,1,'2026-09-23 00:53:51'),(26,'2026-09-16',0.00,60.00,40.00,225000.00,135000.00,90000.00,1,'2026-09-23 00:53:51'),(27,'2026-09-17',0.00,60.00,40.00,43000.00,25800.00,17200.00,1,'2026-09-23 00:53:51');
/*!40000 ALTER TABLE `cierres_diarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cita_detalle`
--

DROP TABLE IF EXISTS `cita_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cita_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cita_id` int(11) NOT NULL,
  `servicio_id` int(11) NOT NULL,
  `precio_cobrado` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cita_detalle_cita` (`cita_id`),
  KEY `fk_cita_detalle_servicio` (`servicio_id`),
  CONSTRAINT `fk_cita_detalle_cita` FOREIGN KEY (`cita_id`) REFERENCES `citas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cita_detalle_servicio` FOREIGN KEY (`servicio_id`) REFERENCES `servicios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cita_detalle`
--

LOCK TABLES `cita_detalle` WRITE;
/*!40000 ALTER TABLE `cita_detalle` DISABLE KEYS */;
INSERT INTO `cita_detalle` VALUES (1,1,3,20000.00),(2,2,3,20000.00),(3,3,2,14000.00),(4,4,3,20000.00),(5,5,3,20000.00),(6,6,2,14000.00),(7,7,5,10000.00),(8,8,3,20000.00),(9,9,3,20000.00),(10,10,1,12000.00),(11,11,3,20000.00),(12,12,3,20000.00),(13,13,3,20000.00),(14,14,3,20000.00),(15,15,2,14000.00),(16,16,5,10000.00),(17,17,3,20000.00),(18,18,3,20000.00),(19,19,3,20000.00),(20,20,3,20000.00),(21,21,4,8000.00),(22,22,4,8000.00),(23,23,3,20000.00),(24,24,3,20000.00),(25,25,3,20000.00),(26,26,4,8000.00),(27,27,3,20000.00),(28,28,3,20000.00),(29,29,3,20000.00),(30,30,2,14000.00),(31,31,5,10000.00),(32,32,3,20000.00),(33,33,3,20000.00),(34,34,3,20000.00),(35,35,3,20000.00),(36,36,3,20000.00),(37,37,2,14000.00),(38,38,3,20000.00),(39,39,3,20000.00),(40,40,3,20000.00),(41,41,3,20000.00),(42,42,3,20000.00),(43,43,3,20000.00),(44,44,3,20000.00),(45,45,3,20000.00),(46,46,3,20000.00),(47,47,3,20000.00),(48,48,4,8000.00),(49,49,4,8000.00),(50,50,3,20000.00),(51,51,3,20000.00),(52,52,3,20000.00),(53,53,3,20000.00),(54,54,3,20000.00),(55,55,3,20000.00),(56,56,1,12000.00),(57,57,3,20000.00),(58,58,3,20000.00),(59,59,3,20000.00),(60,60,3,20000.00),(61,61,3,20000.00),(62,62,3,20000.00),(63,63,5,9000.00),(64,64,3,20000.00),(65,65,4,8000.00),(66,66,5,7000.00),(67,67,1,12000.00),(68,68,3,20000.00),(69,69,3,20000.00),(70,70,3,20000.00),(71,71,3,20000.00),(72,72,3,20000.00),(73,73,3,20000.00),(74,74,2,14000.00),(75,75,4,8000.00),(76,76,3,20000.00),(77,77,4,8000.00),(78,78,5,7000.00),(79,79,3,20000.00),(80,80,3,20000.00),(81,81,2,14000.00),(82,82,4,8000.00),(83,83,3,20000.00),(84,84,3,20000.00),(85,85,2,14000.00),(86,86,3,20000.00),(87,87,3,20000.00),(88,88,4,8000.00),(89,89,3,20000.00),(90,90,3,20000.00),(91,91,3,20000.00),(92,92,2,14000.00),(93,93,5,10000.00),(94,94,3,20000.00),(95,95,3,20000.00),(96,96,3,20000.00),(97,97,3,20000.00),(98,98,5,6000.00),(99,99,3,20000.00),(100,100,3,20000.00),(101,101,3,20000.00),(102,102,3,20000.00),(103,103,5,9000.00),(104,104,3,20000.00),(105,105,3,20000.00),(106,106,3,20000.00),(107,107,3,20000.00),(108,108,3,20000.00),(109,109,1,12000.00),(110,110,5,6000.00),(111,111,3,20000.00),(112,112,3,20000.00),(113,113,3,20000.00),(114,114,3,20000.00),(115,115,3,20000.00),(116,116,3,20000.00),(117,117,2,14000.00),(118,118,4,8000.00),(119,119,3,20000.00),(120,120,5,6000.00),(121,121,3,20000.00),(122,122,5,6000.00),(123,123,3,20000.00),(124,124,3,20000.00),(125,125,3,20000.00),(126,126,1,12000.00),(127,127,5,6000.00),(128,128,3,20000.00),(129,129,4,8000.00),(130,130,3,20000.00),(131,131,3,20000.00),(132,132,2,14000.00),(133,133,5,9000.00),(134,134,3,20000.00),(135,135,1,12000.00),(136,136,5,6000.00),(137,137,2,14000.00),(138,138,5,10000.00),(139,139,3,20000.00),(140,140,4,8000.00),(141,141,3,20000.00),(142,142,3,20000.00),(143,143,3,20000.00),(144,144,3,20000.00),(145,145,5,6000.00),(146,146,3,20000.00),(147,147,4,8000.00),(148,148,5,7000.00),(149,149,3,20000.00),(150,150,2,14000.00),(151,151,5,7000.00),(152,152,3,20000.00),(153,153,3,20000.00),(154,154,2,14000.00),(155,155,3,20000.00),(156,156,3,20000.00),(157,157,3,20000.00),(158,158,2,14000.00),(159,159,5,9000.00),(160,160,4,8000.00),(161,161,5,9000.00),(162,162,1,12000.00),(163,163,5,6000.00);
/*!40000 ALTER TABLE `cita_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citas`
--

DROP TABLE IF EXISTS `citas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `trabajador_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `estado` enum('Pendiente','Terminado_Esperando_Pago','Completada','Cancelada') DEFAULT 'Pendiente',
  `descuento` decimal(10,2) DEFAULT 0.00,
  `metodo_pago` enum('Efectivo','Transferencia','Tarjeta','Otro') DEFAULT NULL,
  `premio_entregado` varchar(100) DEFAULT NULL,
  `total_pagado` decimal(10,2) DEFAULT 0.00,
  `decant_entregado` varchar(150) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_citas_cliente` (`cliente_id`),
  KEY `fk_citas_trabajador` (`trabajador_id`),
  CONSTRAINT `fk_citas_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_citas_trabajador` FOREIGN KEY (`trabajador_id`) REFERENCES `trabajadores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citas`
--

LOCK TABLES `citas` WRITE;
/*!40000 ALTER TABLE `citas` DISABLE KEYS */;
INSERT INTO `citas` VALUES (1,1,1,'2026-08-17','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(2,2,1,'2026-08-17','11:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(3,1,1,'2026-08-17','13:00:00','Completada',0.00,'Transferencia',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(4,2,1,'2026-08-18','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(5,1,1,'2026-08-18','11:30:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(6,2,1,'2026-08-18','13:00:00','Completada',0.00,'Tarjeta',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(7,1,1,'2026-08-18','15:00:00','Completada',0.00,'Efectivo',NULL,10000.00,NULL,'2026-09-23 00:53:51'),(8,2,1,'2026-08-19','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(9,1,1,'2026-08-19','11:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(10,2,1,'2026-08-19','13:00:00','Completada',0.00,'Efectivo',NULL,12000.00,NULL,'2026-09-23 00:53:51'),(11,1,1,'2026-08-21','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(12,2,1,'2026-08-21','11:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(13,1,1,'2026-08-21','13:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(14,2,1,'2026-08-21','15:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(15,1,1,'2026-08-21','16:30:00','Completada',0.00,'Efectivo',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(16,2,1,'2026-08-21','18:00:00','Completada',0.00,'Tarjeta',NULL,10000.00,NULL,'2026-09-23 00:53:51'),(17,1,1,'2026-08-22','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(18,2,1,'2026-08-22','11:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(19,1,1,'2026-08-22','13:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(20,2,1,'2026-08-22','15:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(21,1,1,'2026-08-22','16:30:00','Completada',0.00,'Tarjeta',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(22,2,1,'2026-08-22','18:00:00','Completada',0.00,'Transferencia',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(23,1,1,'2026-08-24','10:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(24,2,1,'2026-08-24','11:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(25,1,1,'2026-08-24','13:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(26,2,1,'2026-08-24','15:00:00','Completada',0.00,'Tarjeta',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(27,1,1,'2026-08-25','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(28,2,1,'2026-08-25','11:30:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(29,1,1,'2026-08-25','13:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(30,2,1,'2026-08-25','15:00:00','Completada',0.00,'Tarjeta',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(31,1,1,'2026-08-25','16:30:00','Completada',0.00,'Tarjeta',NULL,10000.00,NULL,'2026-09-23 00:53:51'),(32,2,1,'2026-08-26','10:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(33,1,1,'2026-08-26','11:30:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(34,2,1,'2026-08-26','13:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(35,1,1,'2026-08-26','15:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(36,2,1,'2026-08-27','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(37,1,1,'2026-08-27','11:30:00','Completada',0.00,'Tarjeta',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(38,2,1,'2026-08-28','10:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(39,1,1,'2026-08-28','11:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(40,2,1,'2026-08-28','13:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(41,1,1,'2026-08-28','15:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(42,2,1,'2026-08-28','16:30:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(43,1,1,'2026-08-29','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(44,2,1,'2026-08-29','11:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(45,1,1,'2026-08-29','13:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(46,2,1,'2026-08-29','15:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(47,1,1,'2026-08-29','16:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(48,2,1,'2026-08-29','18:00:00','Completada',0.00,'Efectivo',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(49,1,1,'2026-08-29','19:15:00','Completada',0.00,'Transferencia',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(50,2,1,'2026-08-31','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(51,1,1,'2026-08-31','11:30:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(52,2,1,'2026-08-31','13:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(53,1,1,'2026-08-31','15:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(54,2,1,'2026-09-01','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(55,1,1,'2026-09-01','11:30:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(56,2,1,'2026-09-01','13:00:00','Completada',0.00,'Efectivo',NULL,12000.00,NULL,'2026-09-23 00:53:51'),(57,1,1,'2026-09-02','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(58,2,1,'2026-09-02','11:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(59,1,1,'2026-09-02','13:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(60,2,1,'2026-09-02','15:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(61,1,1,'2026-09-02','16:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(62,2,1,'2026-09-02','18:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(63,1,1,'2026-09-02','19:15:00','Completada',0.00,'Transferencia',NULL,9000.00,NULL,'2026-09-23 00:53:51'),(64,2,1,'2026-09-03','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(65,1,1,'2026-09-03','11:30:00','Completada',0.00,'Efectivo',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(66,2,1,'2026-09-03','13:00:00','Completada',0.00,'Efectivo',NULL,7000.00,NULL,'2026-09-23 00:53:51'),(67,1,1,'2026-09-04','10:00:00','Completada',0.00,'Transferencia',NULL,12000.00,NULL,'2026-09-23 00:53:51'),(68,2,1,'2026-09-05','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(69,1,1,'2026-09-05','11:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(70,2,1,'2026-09-05','13:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(71,1,1,'2026-09-05','15:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(72,2,1,'2026-09-05','16:30:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(73,1,1,'2026-09-05','18:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(74,2,1,'2026-09-05','19:15:00','Completada',0.00,'Transferencia',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(75,1,1,'2026-09-05','20:00:00','Completada',0.00,'Transferencia',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(76,2,1,'2026-09-07','10:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(77,1,1,'2026-09-07','11:30:00','Completada',0.00,'Tarjeta',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(78,2,1,'2026-09-07','13:00:00','Completada',0.00,'Transferencia',NULL,7000.00,NULL,'2026-09-23 00:53:51'),(79,1,1,'2026-09-08','10:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(80,2,1,'2026-09-08','11:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(81,1,1,'2026-09-08','13:00:00','Completada',0.00,'Transferencia',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(82,2,1,'2026-09-08','15:00:00','Completada',0.00,'Transferencia',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(83,1,1,'2026-09-09','10:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(84,2,1,'2026-09-09','11:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(85,1,1,'2026-09-09','13:00:00','Completada',0.00,'Transferencia',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(86,2,1,'2026-09-10','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(87,1,1,'2026-09-10','11:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(88,2,1,'2026-09-10','13:00:00','Completada',0.00,'Transferencia',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(89,1,1,'2026-09-11','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(90,2,1,'2026-09-11','11:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(91,1,1,'2026-09-11','13:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(92,2,1,'2026-09-11','15:00:00','Completada',0.00,'Efectivo',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(93,1,1,'2026-09-11','16:30:00','Completada',0.00,'Tarjeta',NULL,10000.00,NULL,'2026-09-23 00:53:51'),(94,2,1,'2026-09-12','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(95,1,1,'2026-09-12','11:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(96,2,1,'2026-09-12','13:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(97,1,1,'2026-09-12','15:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(98,2,1,'2026-09-12','16:30:00','Completada',0.00,'Transferencia',NULL,6000.00,NULL,'2026-09-23 00:53:51'),(99,1,1,'2026-09-14','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(100,2,1,'2026-09-14','11:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(101,1,1,'2026-09-14','13:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(102,2,1,'2026-09-14','15:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(103,1,1,'2026-09-14','16:30:00','Completada',0.00,'Efectivo',NULL,9000.00,NULL,'2026-09-23 00:53:51'),(104,2,1,'2026-09-15','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(105,1,1,'2026-09-15','11:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(106,2,1,'2026-09-15','13:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(107,1,1,'2026-09-15','15:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(108,2,1,'2026-09-15','16:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(109,1,1,'2026-09-15','18:00:00','Completada',0.00,'Tarjeta',NULL,12000.00,NULL,'2026-09-23 00:53:51'),(110,2,1,'2026-09-15','19:15:00','Completada',0.00,'Transferencia',NULL,6000.00,NULL,'2026-09-23 00:53:51'),(111,1,1,'2026-09-16','10:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(112,2,1,'2026-09-16','11:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(113,1,1,'2026-09-16','13:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(114,2,1,'2026-09-16','15:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(115,1,1,'2026-09-16','16:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(116,2,1,'2026-09-16','18:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(117,1,1,'2026-09-16','19:15:00','Completada',0.00,'Efectivo',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(118,2,1,'2026-09-16','20:00:00','Completada',0.00,'Tarjeta',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(119,1,1,'2026-09-17','10:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(120,2,1,'2026-09-17','11:30:00','Completada',0.00,'Tarjeta',NULL,6000.00,NULL,'2026-09-23 00:53:51'),(121,1,2,'2026-08-31','10:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(122,2,2,'2026-08-31','11:30:00','Completada',0.00,'Tarjeta',NULL,6000.00,NULL,'2026-09-23 00:53:51'),(123,1,2,'2026-09-01','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(124,2,2,'2026-09-01','11:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(125,1,2,'2026-09-02','10:00:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(126,2,2,'2026-09-02','11:30:00','Completada',0.00,'Tarjeta',NULL,12000.00,NULL,'2026-09-23 00:53:51'),(127,1,2,'2026-09-02','13:00:00','Completada',0.00,'Transferencia',NULL,6000.00,NULL,'2026-09-23 00:53:51'),(128,2,2,'2026-09-03','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(129,1,2,'2026-09-03','11:30:00','Completada',0.00,'Transferencia',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(130,2,2,'2026-09-05','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(131,1,2,'2026-09-05','11:30:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(132,2,2,'2026-09-05','13:00:00','Completada',0.00,'Tarjeta',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(133,1,2,'2026-09-05','15:00:00','Completada',0.00,'Transferencia',NULL,9000.00,NULL,'2026-09-23 00:53:51'),(134,2,2,'2026-09-07','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(135,1,2,'2026-09-07','11:30:00','Completada',0.00,'Transferencia',NULL,12000.00,NULL,'2026-09-23 00:53:51'),(136,2,2,'2026-09-07','13:00:00','Completada',0.00,'Efectivo',NULL,6000.00,NULL,'2026-09-23 00:53:51'),(137,1,2,'2026-09-08','10:00:00','Completada',0.00,'Transferencia',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(138,2,2,'2026-09-08','11:30:00','Completada',0.00,'Tarjeta',NULL,10000.00,NULL,'2026-09-23 00:53:51'),(139,1,2,'2026-09-09','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(140,2,2,'2026-09-09','11:30:00','Completada',0.00,'Efectivo',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(141,1,2,'2026-09-10','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(142,2,2,'2026-09-10','11:30:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(143,1,2,'2026-09-11','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(144,2,2,'2026-09-11','11:30:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(145,1,2,'2026-09-11','13:00:00','Completada',0.00,'Tarjeta',NULL,6000.00,NULL,'2026-09-23 00:53:51'),(146,2,2,'2026-09-12','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(147,1,2,'2026-09-12','11:30:00','Completada',0.00,'Tarjeta',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(148,2,2,'2026-09-12','13:00:00','Completada',0.00,'Transferencia',NULL,7000.00,NULL,'2026-09-23 00:53:51'),(149,1,2,'2026-09-14','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(150,2,2,'2026-09-14','11:30:00','Completada',0.00,'Tarjeta',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(151,1,2,'2026-09-14','13:00:00','Completada',0.00,'Efectivo',NULL,7000.00,NULL,'2026-09-23 00:53:51'),(152,2,2,'2026-09-15','10:00:00','Completada',0.00,'Transferencia',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(153,1,2,'2026-09-15','11:30:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(154,2,2,'2026-09-15','13:00:00','Completada',0.00,'Tarjeta',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(155,1,2,'2026-09-16','10:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(156,2,2,'2026-09-16','11:30:00','Completada',0.00,'Tarjeta',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(157,1,2,'2026-09-16','13:00:00','Completada',0.00,'Efectivo',NULL,20000.00,NULL,'2026-09-23 00:53:51'),(158,2,2,'2026-09-16','15:00:00','Completada',0.00,'Tarjeta',NULL,14000.00,NULL,'2026-09-23 00:53:51'),(159,1,2,'2026-09-16','16:30:00','Completada',0.00,'Efectivo',NULL,9000.00,NULL,'2026-09-23 00:53:51'),(160,2,2,'2026-09-17','10:00:00','Completada',0.00,'Transferencia',NULL,8000.00,NULL,'2026-09-23 00:53:51'),(161,1,2,'2026-09-17','11:30:00','Completada',0.00,'Transferencia',NULL,9000.00,NULL,'2026-09-23 00:53:51'),(162,12,1,'2026-09-22','10:00:00','Completada',0.00,'Efectivo',NULL,12000.00,NULL,'2026-09-23 01:41:27'),(163,13,2,'2026-09-22','10:00:00','Completada',0.00,'Efectivo',NULL,6000.00,NULL,'2026-09-23 01:42:13');
/*!40000 ALTER TABLE `citas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `google_id` varchar(255) DEFAULT NULL,
  `rut` varchar(12) DEFAULT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `foto_perfil` varchar(255) DEFAULT NULL,
  `cortes_acumulados` int(11) DEFAULT 0,
  `decants_disponibles` int(11) DEFAULT 0,
  `notas_crm` text DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `google_id` (`google_id`),
  UNIQUE KEY `rut` (`rut`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,NULL,'12345678-9','Cliente Prueba','cliente@email.com','+56900000000',NULL,81,0,'Cliente frecuente, prefiere degradado bajo con navaja.','$2y$10$/wTbOmoYH7J7IdAQbxmFoe5Dr2oeT7eV8FVmmKayl9CHBfWnqu58G','2026-09-01 15:40:54'),(2,NULL,'19123456-7','Juan Pérez','juan.perez@email.com','+56911111111',NULL,80,0,'Puntual, toma café en cada visita.','$2y$10$/wTbOmoYH7J7IdAQbxmFoe5Dr2oeT7eV8FVmmKayl9CHBfWnqu58G','2026-09-01 15:40:54'),(3,NULL,'18765432-1','Carlos Silva','carlos.silva@email.com','+56922222222',NULL,0,0,'Cliente VIP. Le gusta Creed Aventus.','$2y$10$/wTbOmoYH7J7IdAQbxmFoe5Dr2oeT7eV8FVmmKayl9CHBfWnqu58G','2026-09-01 15:40:54'),(4,NULL,'20555666-8','Miguel Rojas','miguel.rojo@email.com','+56933333333',NULL,0,0,'Prefiere toalla tibia antes del afeitado.','$2y$10$/wTbOmoYH7J7IdAQbxmFoe5Dr2oeT7eV8FVmmKayl9CHBfWnqu58G','2026-09-01 15:40:54'),(5,NULL,'17444333-2','Felipe Soto','felipe.soto@email.com','+56944444444',NULL,0,0,'Atiende los fines de semana con Carlos.','$2y$10$/wTbOmoYH7J7IdAQbxmFoe5Dr2oeT7eV8FVmmKayl9CHBfWnqu58G','2026-09-01 15:40:54'),(6,NULL,'16888999-5','Andrés Castro','andres.castro@email.com','+56955555555',NULL,0,0,'Tratamiento capilar regular.','$2y$10$/wTbOmoYH7J7IdAQbxmFoe5Dr2oeT7eV8FVmmKayl9CHBfWnqu58G','2026-09-01 15:40:54'),(7,NULL,'15777888-K','Matías Silva','matias.silva@email.com','+56966666666',NULL,0,0,'Cliente fiel.','$2y$10$/wTbOmoYH7J7IdAQbxmFoe5Dr2oeT7eV8FVmmKayl9CHBfWnqu58G','2026-09-01 15:40:54'),(8,NULL,'21222333-4','Ignacio Vega','ignacio.vega@email.com','+56977777777',NULL,0,0,'Estudiante universitario.','$2y$10$/wTbOmoYH7J7IdAQbxmFoe5Dr2oeT7eV8FVmmKayl9CHBfWnqu58G','2026-09-01 15:40:54'),(9,NULL,'19888777-6','Bastián Morales','bastian.morales@email.com','+56988888888',NULL,0,0,'Cliente VIP. Fanático de las gorras snapback.','$2y$10$/wTbOmoYH7J7IdAQbxmFoe5Dr2oeT7eV8FVmmKayl9CHBfWnqu58G','2026-09-01 15:40:54'),(10,NULL,'18333222-1','Tomás Riquelme','tomas.riquelme@email.com','+56999999999',NULL,0,0,'Corte clásico tijera.','$2y$10$/wTbOmoYH7J7IdAQbxmFoe5Dr2oeT7eV8FVmmKayl9CHBfWnqu58G','2026-09-01 15:40:54'),(11,NULL,'11222333-4','Cliente Rápido CRM','rapido@email.com','+56988776655',NULL,0,0,'Cliente creado directo desde el panel CRM','$2y$10$bmSD2xY0FdR3jqRiwHi4GefT/PnLVqmWNe6rnpaB355E2fp7R4lmG','2026-09-01 15:55:08'),(12,NULL,'20993899-5','Brilan Bugueno','express_209938995@laromana.cl','+569 49384043',NULL,1,0,NULL,NULL,'2026-09-23 01:41:27'),(13,NULL,'12312332-3','Egias','express_123123323@laromana.cl','3213123',NULL,1,0,NULL,NULL,'2026-09-23 01:42:13');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuraciones`
--

DROP TABLE IF EXISTS `configuraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuraciones` (
  `clave` varchar(50) NOT NULL,
  `valor` text NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuraciones`
--

LOCK TABLES `configuraciones` WRITE;
/*!40000 ALTER TABLE `configuraciones` DISABLE KEYS */;
INSERT INTO `configuraciones` VALUES ('frecuencia_pago_barberos','quincenal','Frecuencia de pago predeterminada para barberos (semanal, quincenal, mensual)','2026-09-23 01:37:46'),('meta_cortes_premio','3','Cantidad de cortes requeridos para ganar premio','2026-09-01 15:58:05');
/*!40000 ALTER TABLE `configuraciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historial_recompensas`
--

DROP TABLE IF EXISTS `historial_recompensas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historial_recompensas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `cita_id` int(11) DEFAULT NULL,
  `aroma_decant` varchar(150) DEFAULT NULL,
  `fecha_entrega` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_recompensas_cliente` (`cliente_id`),
  KEY `fk_recompensas_cita` (`cita_id`),
  CONSTRAINT `fk_recompensas_cita` FOREIGN KEY (`cita_id`) REFERENCES `citas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_recompensas_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_recompensas`
--

LOCK TABLES `historial_recompensas` WRITE;
/*!40000 ALTER TABLE `historial_recompensas` DISABLE KEYS */;
/*!40000 ALTER TABLE `historial_recompensas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos_trabajadores`
--

DROP TABLE IF EXISTS `pagos_trabajadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos_trabajadores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trabajador_id` int(11) NOT NULL,
  `periodo_inicio` date NOT NULL,
  `periodo_fin` date NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha_pago` date NOT NULL,
  `metodo_pago` enum('Transferencia','Efectivo','Tarjeta','Cheque','Otro') DEFAULT 'Transferencia',
  `numero_comprobante` varchar(100) DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `trabajador_id` (`trabajador_id`),
  CONSTRAINT `pagos_trabajadores_ibfk_1` FOREIGN KEY (`trabajador_id`) REFERENCES `trabajadores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos_trabajadores`
--

LOCK TABLES `pagos_trabajadores` WRITE;
/*!40000 ALTER TABLE `pagos_trabajadores` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos_trabajadores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedido_detalle`
--

DROP TABLE IF EXISTS `pedido_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedido_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pedido_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pedido_detalle_pedido` (`pedido_id`),
  KEY `fk_pedido_detalle_producto` (`producto_id`),
  CONSTRAINT `fk_pedido_detalle_pedido` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pedido_detalle_producto` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido_detalle`
--

LOCK TABLES `pedido_detalle` WRITE;
/*!40000 ALTER TABLE `pedido_detalle` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedido_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `estado` varchar(50) DEFAULT 'Pendiente',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `metodo_pago` varchar(50) DEFAULT 'Efectivo',
  PRIMARY KEY (`id`),
  KEY `fk_pedidos_cliente` (`cliente_id`),
  CONSTRAINT `fk_pedidos_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `imagen_url` longtext DEFAULT NULL,
  `ventas` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `fk_productos_categoria` (`categoria_id`),
  CONSTRAINT `fk_productos_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,1,'Pomada Fijación Extra Fuerte','Acabado mate, fijación 24h, base agua',12000.00,35,NULL,42),(2,1,'Shampoo Anticaída La Romana','Nutrición con biotina y romero 300ml',14000.00,20,NULL,28),(3,1,'Cera Modeladora Texturizante','Brillo natural y textura ligera',10000.00,24,NULL,19),(4,2,'Decant Creed Aventus (10ml)','Perfume nicho exclusivo notas cítricas y ahumadas',20000.00,47,'/assets/fotos/perfume/decant.png',65),(5,2,'Decant Tom Ford Oud Wood (10ml)','Aroma amaderado refinado de lujo',22000.00,30,'/assets/fotos/perfume/decant.png',38),(6,2,'Perfume Dior Sauvage (100ml)','Eau de Parfum original de alta duración',120000.00,8,'/assets/fotos/perfume/perfume2.jpg',12),(7,2,'Perfume Bleu de Chanel (100ml)','Sofisticación masculina amaderada aromática',110000.00,6,'/assets/fotos/perfume/Perfume1.webp',9),(8,3,'Gorra Azul La Romana','Gorra urbana azul con logo bordado dorado',25000.00,24,'/assets/fotos/gorras/Gorra azul.jpg',22),(9,3,'Gorra Roja Premium','Gorra snapback roja con detalles negros',25000.00,18,'/assets/fotos/gorras/Gorra roja.webp',15),(10,3,'Gorra Trucker Black Edition','Malla trasera transpirable edición especial',18000.00,30,'/assets/fotos/gorras/gorra_trucker.png',31);
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicios`
--

DROP TABLE IF EXISTS `servicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `es_corte` tinyint(1) DEFAULT 0,
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicios`
--

LOCK TABLES `servicios` WRITE;
/*!40000 ALTER TABLE `servicios` DISABLE KEYS */;
INSERT INTO `servicios` VALUES (1,'Corte Clásico','Corte de cabello tradicional con lavado y peinado',12000.00,1,1),(2,'Corte Degradado','Corte fade pulido a navaja y peinado profesional',14000.00,1,1),(3,'Corte y Barba Completa','Pack completo de corte de cabello y arreglo de barba con toalla caliente',20000.00,1,1),(4,'Perfilado de Barba','Diseño de barba a navaja y tratamiento de aceites',8000.00,0,1),(5,'Black Mask & Limpieza Facial','Mascarilla purificante y toalla caliente',6000.00,0,1);
/*!40000 ALTER TABLE `servicios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trabajadores`
--

DROP TABLE IF EXISTS `trabajadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trabajadores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `foto_perfil` longtext DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `password_hash` varchar(255) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `frecuencia_pago` varchar(20) DEFAULT 'quincenal',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trabajadores`
--

LOCK TABLES `trabajadores` WRITE;
/*!40000 ALTER TABLE `trabajadores` DISABLE KEYS */;
INSERT INTO `trabajadores` VALUES (1,'David H.','david@laromana.cl','/assets/fotos/Peersonal/Peluquero 1.jpg',1,'$2y$10$oHcrImTodeJNu0MrMASsDe.AGDdWG/cxESe4yoZO13FFlYoBfilUy','2026-09-01 15:40:54','quincenal'),(2,'Santiago','santiago@laromana.cl','/assets/fotos/Peersonal/Peelukero2.jpg',1,'$2y$10$oHcrImTodeJNu0MrMASsDe.AGDdWG/cxESe4yoZO13FFlYoBfilUy','2026-09-01 15:40:54','quincenal');
/*!40000 ALTER TABLE `trabajadores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-22 23:13:08
